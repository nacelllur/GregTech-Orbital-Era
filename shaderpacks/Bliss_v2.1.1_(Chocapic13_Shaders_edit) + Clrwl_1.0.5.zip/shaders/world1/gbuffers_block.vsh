#version 120

#define WORLD
#define BLOCKENTITIES

#define END_SHADER

#include "/dimensions/all_solid.vsh"